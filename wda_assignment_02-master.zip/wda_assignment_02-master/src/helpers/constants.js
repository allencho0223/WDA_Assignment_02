// MIN YOUNG
const apiurl = 'http://localhost/wda_assignment_01/public/';

//THEON
// const apiurl = 'http://localhost/rmit-laravel/assignment01/public/';


export { apiurl };